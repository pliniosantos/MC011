class Main
{
    public static void main(String[] args)
    {
        System.out.println( new Classe().doIt() );
    }
}

class Classe
{
    int i;
    int i;

    public int i(int a, int[] a)
    {
        int a;
        int b;
        int b;

        return i;
    }

    public int[] i()
    {
        return new int[10];
    }
}

class Classe
{
   public int doIt()
   {
      return 0;
   }
}
