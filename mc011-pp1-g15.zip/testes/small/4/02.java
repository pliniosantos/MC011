class Principal
{
    public static void main(String[] args)
    {
        {
           a[new Obj()] = false;
        }
    }
}

class Obj
{
}
